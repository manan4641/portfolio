<?php
/**
 * Plugin Name: WPImages WebP Converter
 * Plugin URI: https://abdulmanan.dev/products
 * Description: Automatically convert JPG/PNG images to WebP format for better performance. Supports Gutenberg, Elementor, Media Library, and batch conversion with progress tracking.
 * Version: 1.0.3
 * Requires at least: 5.5
 * Requires PHP: 7.4
 * Author: Abdul Manan
 * Author URI: https://abdulmanan.dev
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wpimages-webp
 * Domain Path: /languages
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Plugin constants
define( 'WPIMAGES_WEBP_VERSION', '1.0.3' );
define( 'WPIMAGES_WEBP_PLUGIN_FILE', __FILE__ );
define( 'WPIMAGES_WEBP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPIMAGES_WEBP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WPIMAGES_WEBP_INCLUDES_DIR', WPIMAGES_WEBP_PLUGIN_DIR . 'includes/' );
define( 'WPIMAGES_WEBP_ASSETS_URL', WPIMAGES_WEBP_PLUGIN_URL . 'assets/' );

/**
 * Main plugin class
 */
class WPImages_WebP {
	
	/**
	 * Single instance
	 */
	private static $instance = null;
	
	/**
	 * Get instance
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->load_dependencies();
		$this->init_hooks();
	}
	
	/**
	 * Load required files
	 */
	private function load_dependencies() {
		require_once WPIMAGES_WEBP_INCLUDES_DIR . 'helpers.php';
		require_once WPIMAGES_WEBP_INCLUDES_DIR . 'class-converter.php';
		require_once WPIMAGES_WEBP_INCLUDES_DIR . 'class-scanner.php';
		require_once WPIMAGES_WEBP_INCLUDES_DIR . 'class-frontend.php';
		require_once WPIMAGES_WEBP_INCLUDES_DIR . 'class-batch-processor.php';
		
		if ( is_admin() ) {
			require_once WPIMAGES_WEBP_INCLUDES_DIR . 'class-admin.php';
		}
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		// Activation/Deactivation
		register_activation_hook( WPIMAGES_WEBP_PLUGIN_FILE, array( $this, 'activate' ) );
		register_deactivation_hook( WPIMAGES_WEBP_PLUGIN_FILE, array( $this, 'deactivate' ) );
		
		// Initialize components
		add_action( 'plugins_loaded', array( $this, 'init_components' ) );
		
		// Load textdomain
		add_action( 'init', array( $this, 'load_textdomain' ) );
	}
	
	/**
	 * Activation hook
	 */
	public function activate() {
		// Set default options
		$default_options = array(
			'quality'              => 80,
			'post_types'           => array( 'post', 'page' ),
			'convert_media_library' => false,
			'auto_convert_uploads' => true,
			'frontend_replacement' => true,
		);
		
		add_option( 'wpimages_webp_settings', $default_options );
		
		// Show activation notice
		set_transient( 'wpimages_webp_activation_notice', true, 60 );
		
		// Log activation
		wpimages_webp_log( 'Plugin activated', 'info' );
	}
	
	/**
	 * Deactivation hook
	 */
	public function deactivate() {
		// Clean up transients
		delete_transient( 'wpimages_webp_activation_notice' );
		
		// Clean up any batch processing transients
		global $wpdb;
		$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_wpimages_webp_progress_%'" );
		$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_wpimages_webp_progress_%'" );
		
		wpimages_webp_log( 'Plugin deactivated', 'info' );
	}
	
	/**
	 * Initialize plugin components
	 */
	public function init_components() {
		// Initialize frontend replacement
		WPImages_WebP_Frontend::get_instance();
		
		// Initialize batch processor
		WPImages_WebP_Batch_Processor::get_instance();
		
		// Initialize admin
		if ( is_admin() ) {
			WPImages_WebP_Admin::get_instance();
		}
		
		// Auto-convert on save (if not using batch mode)
		$settings = wpimages_webp_get_option( 'settings', array() );
		if ( ! empty( $settings['auto_convert_on_save'] ) ) {
			add_action( 'save_post', array( $this, 'auto_convert_on_save' ), 20, 3 );
		}
		
		// Auto-convert new uploads
		if ( wpimages_webp_get_option( 'auto_convert_uploads', true ) ) {
			add_filter( 'wp_generate_attachment_metadata', array( $this, 'auto_convert_new_upload' ), 10, 2 );
		}
	}
	
	/**
	 * Auto-convert images when post is saved
	 */
	public function auto_convert_on_save( $post_id, $post, $update ) {
		// Skip autosave/revisions
		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}
		
		// Check if post type is enabled
		$post_types = wpimages_webp_get_option( 'post_types', array( 'post', 'page' ) );
		if ( ! in_array( $post->post_type, $post_types, true ) ) {
			return;
		}
		
		// Scan and convert images in this post
		$scanner = new WPImages_WebP_Scanner();
		$images = $scanner->get_images_from_post( $post_id );
		
		if ( ! empty( $images ) ) {
			$converter = new WPImages_WebP_Converter();
			$quality = wpimages_webp_get_option( 'quality', 80 );
			
			foreach ( $images as $attachment_id ) {
				$converter->convert_attachment( $attachment_id, $quality );
			}
		}
	}
	
	/**
	 * Auto-convert new uploads
	 */
	public function auto_convert_new_upload( $metadata, $attachment_id ) {
		$converter = new WPImages_WebP_Converter();
		$quality = wpimages_webp_get_option( 'quality', 80 );
		$converter->convert_attachment( $attachment_id, $quality );
		
		return $metadata;
	}
	
	/**
	 * Load plugin textdomain
	 */
	public function load_textdomain() {
		// load_plugin_textdomain is not needed for plugins hosted on WordPress.org
		// WordPress automatically loads translations
	}
}

/**
 * Initialize plugin
 */
function wpimages_webp() {
	return WPImages_WebP::get_instance();
}

// Start the plugin
wpimages_webp();
