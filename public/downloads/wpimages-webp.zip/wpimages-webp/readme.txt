=== WPImages WebP Converter ===
Contributors: abdulmanan
Tags: webp, image optimization, performance, elementor, gutenberg
Requires at least: 5.5
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automatically convert JPG/PNG images to WebP format for better performance. Supports Gutenberg, Elementor, and batch conversion.

== Description ==

**WPImages WebP Converter** is a powerful WordPress plugin that automatically converts your JPG and PNG images to the modern WebP format, significantly reducing file sizes while maintaining image quality.

### Key Features

✅ **Batch Conversion** - Convert all existing images with progress tracking
✅ **Auto-Conversion** - Automatically convert new uploads
✅ **Gutenberg Support** - Detects images in all Gutenberg blocks
✅ **Elementor Compatible** - Full support for Elementor pages and widgets
✅ **Smart Scanning** - Finds images in posts, pages, and custom post types
✅ **Quality Control** - Adjustable WebP quality (1-100)
✅ **Safe & Non-Destructive** - Keeps original images intact
✅ **Frontend Replacement** - Automatically serves WebP on the frontend
✅ **Background Images** - Swaps CSS background images to WebP
✅ **Progress Tracking** - Real-time progress bar during conversion
✅ **Detailed Logging** - Track all conversions and errors
✅ **Dry-Run Mode** - Preview what will be converted before starting

### How It Works

1. **Install & Activate** the plugin
2. Go to **Settings → WebP Converter**
3. Configure your quality settings and post types
4. Click **"Scan Images"** to preview
5. Click **"Convert to WebP"** to start
6. Watch the progress bar complete
7. WebP images are automatically served on the frontend

### Technical Features

- Uses **WordPress Image Editor** (Imagick or GD)
- **AJAX batch processing** prevents timeouts
- Converts **original + all thumbnail sizes**
- Handles **srcset** for responsive images
- **Elementor background images** supported
- Comprehensive **error handling** and logging
- **Security hardened** with nonces and capability checks

### Requirements

- WordPress 5.5 or higher
- PHP 7.4 or higher
- GD or Imagick PHP extension with WebP support
- Write permissions to uploads directory

### Performance

WebP images are typically **25-35% smaller** than JPG and **up to 80% smaller** than PNG, significantly improving page load times and Core Web Vitals scores.

== Installation ==

### Automatic Installation

1. Go to **Plugins → Add New**
2. Search for "WPImages WebP Converter"
3. Click **Install Now**
4. Click **Activate**

### Manual Installation

1. Download the plugin ZIP file
2. Go to **Plugins → Add New → Upload Plugin**
3. Choose the downloaded file
4. Click **Install Now**
5. Click **Activate**

### FTP Installation

1. Extract the ZIP file
2. Upload `wpimages-webp` folder to `/wp-content/plugins/`
3. Go to **Plugins** page
4. Activate **WPImages WebP Converter**

== Frequently Asked Questions ==

= Will this delete my original images? =

No! The plugin creates WebP versions alongside your original images. Originals are never deleted.

= What happens if I deactivate the plugin? =

Your site will continue to work normally, serving the original JPG/PNG images. WebP files remain on the server.

= Does it work with Elementor? =

Yes! The plugin fully supports Elementor, including images in widgets, galleries, and background images.

= Does it work with Gutenberg? =

Yes! The plugin detects images in all Gutenberg blocks: Image, Gallery, Cover, Media & Text, and more.

= How do I know if my server supports WebP? =

After activating the plugin, go to Settings → WebP Converter. The page will show your available image editor (Imagick or GD). If neither supports WebP, a warning will appear.

= Can I convert images in custom post types? =

Yes! The settings page allows you to select any public post type for conversion.

= What quality setting should I use? =

We recommend **80-85** for a good balance between quality and file size. Lower values = smaller files but lower quality.

= Will it slow down my site? =

No. Conversion happens in the background via AJAX. Once converted, WebP images are served directly with no performance impact.

= Can I convert the entire Media Library? =

Yes! Enable "Convert Media Library" in settings to include all images, even those not used in posts.

= What if conversion fails for some images? =

The plugin logs all conversions and failures. Check the Logs section in settings for details.

== Screenshots ==

1. Settings page with quality controls and post type selection
2. Batch conversion interface with progress tracking
3. Scan results showing images found
4. Progress bar during conversion
5. Completion summary with statistics
6. Conversion logs viewer

== Changelog ==

= 1.0.0 =
* Initial release
* Batch conversion with AJAX progress tracking
* Auto-conversion for new uploads
* Gutenberg and Elementor support
* Configurable quality settings
* Post type selection
* Frontend WebP replacement
* Background image swap
* Comprehensive logging
* Dry-run mode

== Upgrade Notice ==

= 1.0.0 =
Initial release of WPImages WebP Converter.

== Technical Details ==

### Image Editor Priority

1. **Imagick** (preferred) - Better quality and transparency support
2. **GD** (fallback) - Universally available

### Conversion Strategy

The plugin converts:
- Original uploaded image
- All WordPress-generated thumbnail sizes
- Maintains PNG transparency
- Preserves EXIF data when possible

### Frontend Replacement

- Filters `the_content` for HTML images
- Filters `wp_calculate_image_srcset` for responsive images
- Filters `post_thumbnail_html` for featured images
- JavaScript swap for CSS background images
- Only replaces if WebP file exists

### Security

- All AJAX requests use nonces
- Capability checks: `manage_options`
- Input sanitization and validation
- Output escaping
- File path security checks
- Protected log directory

### Performance Optimization

- Batch processing (20 images per request)
- Transient-based progress tracking
- No database queries in loops
- Conditional script loading
- File existence caching

== Support ==

For support, bug reports, or feature requests, please visit:
https://yourwebsite.com/support

== Privacy ==

This plugin does not collect or transmit any user data. All processing happens locally on your server.
