<?php
/**
 * How It Works Guide Content
 *
 * @package WPImages_WebP
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="wpimages-webp-container">
	<div class="wpimages-webp-guide" style="padding: 30px; line-height: 1.8;">
		
		<h2 style="margin-top: 0; color: #2271b1;">📘 <?php esc_html_e( 'Understanding the Plugin', 'wpimages-webp' ); ?></h2>
		<p><?php esc_html_e( 'This plugin converts JPG and PNG images to WebP format for better performance. It creates WebP versions alongside your original images without deleting them.', 'wpimages-webp' ); ?></p>
		
		<hr style="margin: 30px 0; border: none; border-top: 1px solid #ddd;">
		
		<h2 style="color: #2271b1;">🔢 <?php esc_html_e( 'How Image Counting Works', 'wpimages-webp' ); ?></h2>
		<ul style="list-style: disc; margin-left: 20px;">
			<li><strong><?php esc_html_e( 'Images in Posts:', 'wpimages-webp' ); ?></strong> <?php esc_html_e( 'The plugin scans your selected post types (Pages, Posts, Custom Post Types) and counts only JPG/PNG images that need conversion.', 'wpimages-webp' ); ?></li>
			<li><strong><?php esc_html_e( 'WebP Images Excluded:', 'wpimages-webp' ); ?></strong> <?php esc_html_e( 'Images already in WebP format are automatically excluded from the count.', 'wpimages-webp' ); ?></li>
			<li><strong><?php esc_html_e( 'Media Library Option:', 'wpimages-webp' ); ?></strong> <?php esc_html_e( 'When "Convert entire Media Library" is enabled, it also includes JPG/PNG images not used in any posts.', 'wpimages-webp' ); ?></li>
		</ul>
		
		<hr style="margin: 30px 0; border: none; border-top: 1px solid #ddd;">
		
		<h2 style="color: #2271b1;">📊 <?php esc_html_e( 'Understanding "Skipped" Count', 'wpimages-webp' ); ?></h2>
		<p><strong><?php esc_html_e( 'Important:', 'wpimages-webp' ); ?></strong> <?php esc_html_e( 'The "skipped" number refers to IMAGE SIZES (thumbnails), not individual images.', 'wpimages-webp' ); ?></p>
		<div style="background: #f0f6fc; padding: 15px; border-left: 3px solid #0073aa; margin: 15px 0;">
			<p style="margin: 0 0 10px 0;"><strong><?php esc_html_e( 'Example:', 'wpimages-webp' ); ?></strong></p>
			<ul style="margin: 0 0 0 20px; list-style: disc;">
				<li><?php esc_html_e( 'You have 32 original images', 'wpimages-webp' ); ?></li>
				<li><?php esc_html_e( 'Each image has ~8 sizes (original, large, medium, thumbnail, custom)', 'wpimages-webp' ); ?></li>
				<li><?php esc_html_e( '32 images × 8 sizes = 256 total files', 'wpimages-webp' ); ?></li>
				<li><?php esc_html_e( 'If WebP already exists for 252 sizes → "Skipped: 252"', 'wpimages-webp' ); ?></li>
			</ul>
		</div>
		
		<hr style="margin: 30px 0; border: none; border-top: 1px solid #ddd;">
		
		<h2 style="color: #2271b1;">🖼️ <?php esc_html_e( 'Why JPG Still Shows in Gallery?', 'wpimages-webp' ); ?></h2>
		<p><strong style="color: #00a32a;">✓ <?php esc_html_e( 'This is correct behavior!', 'wpimages-webp' ); ?></strong></p>
		<ul style="list-style: disc; margin-left: 20px;">
			<li><strong><?php esc_html_e( 'Original files kept:', 'wpimages-webp' ); ?></strong> <?php esc_html_e( 'JPG/PNG files remain in your Media Library - they are never deleted.', 'wpimages-webp' ); ?></li>
			<li><strong><?php esc_html_e( 'WebP created alongside:', 'wpimages-webp' ); ?></strong> <?php esc_html_e( 'For each JPG/PNG, a .webp version is created in the same folder.', 'wpimages-webp' ); ?></li>
			<li><strong><?php esc_html_e( 'Admin shows original:', 'wpimages-webp' ); ?></strong> <?php esc_html_e( 'WordPress admin and Media Library display the original files.', 'wpimages-webp' ); ?></li>
			<li><strong><?php esc_html_e( 'Frontend serves WebP:', 'wpimages-webp' ); ?></strong> <?php esc_html_e( 'When visitors view your site, they automatically get WebP images for better performance.', 'wpimages-webp' ); ?></li>
		</ul>
		
		<hr style="margin: 30px 0; border: none; border-top: 1px solid #ddd;">
		
		<h2 style="color: #2271b1;">📝 <?php esc_html_e( 'Step-by-Step Usage Guide', 'wpimages-webp' ); ?></h2>
		<ol style="margin-left: 20px;">
			<li style="margin-bottom: 15px;"><strong><?php esc_html_e( 'Configure Settings', 'wpimages-webp' ); ?></strong>
				<ul style="list-style: circle; margin-left: 20px; margin-top: 8px;">
					<li><?php esc_html_e( 'Set WebP quality (75-85 recommended)', 'wpimages-webp' ); ?></li>
					<li><?php esc_html_e( 'Select post types to scan (Posts, Pages, Custom Post Types)', 'wpimages-webp' ); ?></li>
					<li><?php esc_html_e( 'Enable "Convert entire Media Library" if needed', 'wpimages-webp' ); ?></li>
					<li><?php esc_html_e( 'Enable "Auto-convert new uploads" (recommended)', 'wpimages-webp' ); ?></li>
				</ul>
			</li>
			<li style="margin-bottom: 15px;"><strong><?php esc_html_e( 'Scan Images', 'wpimages-webp' ); ?></strong><br><?php esc_html_e( 'Go to Batch Conversion tab and click "Scan Images" to see how many JPG/PNG images will be converted', 'wpimages-webp' ); ?></li>
			<li style="margin-bottom: 15px;"><strong><?php esc_html_e( 'Review Results', 'wpimages-webp' ); ?></strong><br><?php esc_html_e( 'Check the post details to see which images were found', 'wpimages-webp' ); ?></li>
			<li style="margin-bottom: 15px;"><strong><?php esc_html_e( 'Convert to WebP', 'wpimages-webp' ); ?></strong><br><?php esc_html_e( 'Click "Convert to WebP" and watch the progress bar', 'wpimages-webp' ); ?></li>
			<li style="margin-bottom: 15px;"><strong><?php esc_html_e( 'Verify on Frontend', 'wpimages-webp' ); ?></strong>
				<ul style="list-style: circle; margin-left: 20px; margin-top: 8px;">
					<li><?php esc_html_e( 'Visit your website', 'wpimages-webp' ); ?></li>
					<li><?php esc_html_e( 'Right-click an image → "Open image in new tab"', 'wpimages-webp' ); ?></li>
					<li><?php esc_html_e( 'URL should end in .webp', 'wpimages-webp' ); ?></li>
				</ul>
			</li>
		</ol>
		
		<hr style="margin: 30px 0; border: none; border-top: 1px solid #ddd;">
		
		<h2 style="color: #2271b1;">❓ <?php esc_html_e( 'Frequently Asked Questions', 'wpimages-webp' ); ?></h2>
		
		<!-- FAQ 1 -->
		<details style="margin: 15px 0; border: 1px solid #ddd; padding: 15px; border-radius: 4px; background: #fff;">
			<summary style="cursor: pointer; font-weight: bold; font-size: 15px; color: #2271b1;"><?php esc_html_e( 'Why does scan show fewer images than my Media Library?', 'wpimages-webp' ); ?></summary>
			<div style="padding: 15px 0 0 0; border-top: 1px solid #f0f0f0; margin-top: 10px;">
				<p><?php esc_html_e( 'The scan counts only JPG/PNG images from:', 'wpimages-webp' ); ?></p>
				<ul style="list-style: disc; margin-left: 20px;">
					<li><?php esc_html_e( 'Images used in selected post types (if Media Library option is OFF)', 'wpimages-webp' ); ?></li>
					<li><?php esc_html_e( 'ALL JPG/PNG in Media Library (if option is ON)', 'wpimages-webp' ); ?></li>
					<li><strong><?php esc_html_e( 'Excluded:', 'wpimages-webp' ); ?></strong> <?php esc_html_e( 'WebP images (already converted), GIF, SVG, PDF, and other formats', 'wpimages-webp' ); ?></li>
				</ul>
			</div>
		</details>
		
		<!-- FAQ 2 -->
		<details style="margin: 15px 0; border: 1px solid #ddd; padding: 15px; border-radius: 4px; background: #fff;">
			<summary style="cursor: pointer; font-weight: bold; font-size: 15px; color: #2271b1;"><?php esc_html_e( 'What does "Failed: X" mean in conversion results?', 'wpimages-webp' ); ?></summary>
			<div style="padding: 15px 0 0 0; border-top: 1px solid #f0f0f0; margin-top: 10px;">
				<p><?php esc_html_e( 'These are usually orphaned database entries - WordPress has attachment records but the actual image files were deleted from the server.', 'wpimages-webp' ); ?></p>
				<p><strong><?php esc_html_e( 'To fix:', 'wpimages-webp' ); ?></strong> <?php esc_html_e( 'Use a plugin like "Media Cleaner" to remove orphaned database entries. Check the Logs tab for specific file names.', 'wpimages-webp' ); ?></p>
			</div>
		</details>
		
		<!-- FAQ 3 -->
		<details style="margin: 15px 0; border: 1px solid #ddd; padding: 15px; border-radius: 4px; background: #fff;">
			<summary style="cursor: pointer; font-weight: bold; font-size: 15px; color: #2271b1;"><?php esc_html_e( 'How do I know WebP is working on my website?', 'wpimages-webp' ); ?></summary>
			<div style="padding: 15px 0 0 0; border-top: 1px solid #f0f0f0; margin-top: 10px;">
				<p><strong><?php esc_html_e( 'Method 1: Inspect Element', 'wpimages-webp' ); ?></strong></p>
				<ol style="margin-left: 20px;">
					<li><?php esc_html_e( 'Visit your website, right-click on an image → "Inspect"', 'wpimages-webp' ); ?></li>
					<li><?php esc_html_e( 'Look at the src attribute - it should show .webp', 'wpimages-webp' ); ?></li>
				</ol>
				<p><strong><?php esc_html_e( 'Method 2: Open Image Directly', 'wpimages-webp' ); ?></strong></p>
				<ol style="margin-left: 20px;">
					<li><?php esc_html_e( 'Right-click an image → "Open image in new tab"', 'wpimages-webp' ); ?></li>
					<li><?php esc_html_e( 'URL should end with .webp', 'wpimages-webp' ); ?></li>
				</ol>
			</div>
		</details>
		
		<!-- FAQ 4 -->
		<details style="margin: 15px 0; border: 1px solid #ddd; padding: 15px; border-radius: 4px; background: #fff;">
			<summary style="cursor: pointer; font-weight: bold; font-size: 15px; color: #2271b1;"><?php esc_html_e( 'Does the plugin support custom post types?', 'wpimages-webp' ); ?></summary>
			<div style="padding: 15px 0 0 0; border-top: 1px solid #f0f0f0; margin-top: 10px;">
				<p><strong style="color: #00a32a;">✓ <?php esc_html_e( 'Yes! All public custom post types are automatically supported.', 'wpimages-webp' ); ?></strong></p>
				<p><?php esc_html_e( 'In the Settings tab, you will see checkboxes for all registered public post types including Posts, Pages, and any custom types like Projects, Portfolio, Products, etc.', 'wpimages-webp' ); ?></p>
				<p><strong><?php esc_html_e( 'If you don\'t see your custom post type:', 'wpimages-webp' ); ?></strong> <?php esc_html_e( 'Make sure it\'s registered with \'public\' => true in its registration arguments.', 'wpimages-webp' ); ?></p>
			</div>
		</details>
		
		<!-- FAQ 5 -->
		<details style="margin: 15px 0; border: 1px solid #ddd; padding: 15px; border-radius: 4px; background: #fff;">
			<summary style="cursor: pointer; font-weight: bold; font-size: 15px; color: #2271b1;"><?php esc_html_e( 'Will this slow down my website?', 'wpimages-webp' ); ?></summary>
			<div style="padding: 15px 0 0 0; border-top: 1px solid #f0f0f0; margin-top: 10px;">
				<p><strong style="color: #00a32a;"><?php esc_html_e( 'No - it will make your site FASTER!', 'wpimages-webp' ); ?></strong></p>
				<ul style="list-style: disc; margin-left: 20px;">
					<li><?php esc_html_e( 'WebP images are 25-35% smaller than JPG', 'wpimages-webp' ); ?></li>
					<li><?php esc_html_e( 'Conversion happens once in the background', 'wpimages-webp' ); ?></li>
					<li><?php esc_html_e( 'Frontend delivery is just a simple file check (extremely fast)', 'wpimages-webp' ); ?></li>
					<li><?php esc_html_e( 'No heavy processing on page load', 'wpimages-webp' ); ?></li>
				</ul>
			</div>
		</details>
		
		<!-- FAQ 6 -->
		<details style="margin: 15px 0; border: 1px solid #ddd; padding: 15px; border-radius: 4px; background: #fff;">
			<summary style="cursor: pointer; font-weight: bold; font-size: 15px; color: #2271b1;"><?php esc_html_e( 'What happens if I deactivate the plugin?', 'wpimages-webp' ); ?></summary>
			<div style="padding: 15px 0 0 0; border-top: 1px solid #f0f0f0; margin-top: 10px;">
				<p><?php esc_html_e( 'Your site will continue to work normally:', 'wpimages-webp' ); ?></p>
				<ul style="list-style: disc; margin-left: 20px;">
					<li><?php esc_html_e( 'Original JPG/PNG images will be displayed', 'wpimages-webp' ); ?></li>
					<li><?php esc_html_e( 'WebP files remain on the server (safe to delete manually if needed)', 'wpimages-webp' ); ?></li>
					<li><?php esc_html_e( 'No broken images or errors', 'wpimages-webp' ); ?></li>
				</ul>
			</div>
		</details>
		
		<!-- FAQ 7 -->
		<details style="margin: 15px 0; border: 1px solid #ddd; padding: 15px; border-radius: 4px; background: #fff;">
			<summary style="cursor: pointer; font-weight: bold; font-size: 15px; color: #2271b1;"><?php esc_html_e( 'Can I convert images in WooCommerce products?', 'wpimages-webp' ); ?></summary>
			<div style="padding: 15px 0 0 0; border-top: 1px solid #f0f0f0; margin-top: 10px;">
				<p><strong style="color: #00a32a;">✓ <?php esc_html_e( 'Yes!', 'wpimages-webp' ); ?></strong> <?php esc_html_e( 'WooCommerce "product" is a custom post type. Just check "Products" in the Settings tab post type selection.', 'wpimages-webp' ); ?></p>
				<p><?php esc_html_e( 'All product images (featured, gallery, variations) will be detected and converted.', 'wpimages-webp' ); ?></p>
			</div>
		</details>
		
		<div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 20px; margin-top: 30px; border-radius: 4px;">
			<p style="margin: 0;"><strong>💡 <?php esc_html_e( 'Pro Tip:', 'wpimages-webp' ); ?></strong> <?php esc_html_e( 'Enable "Auto-convert new uploads" in Settings so future images are automatically converted to WebP when you upload them!', 'wpimages-webp' ); ?></p>
		</div>
		
	</div>
</div>
