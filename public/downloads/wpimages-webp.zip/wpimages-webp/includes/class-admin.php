<?php
/**
 * Admin Class
 *
 * @package WPImages_WebP
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles admin interface
 */
class WPImages_WebP_Admin {
	
	/**
	 * Single instance
	 */
	private static $instance = null;
	
	/**
	 * Get instance
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */ 
	private function init_hooks() {
		add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_notices', array( $this, 'activation_notice' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		add_action( 'wp_ajax_wpimages_webp_scan', array( $this, 'ajax_scan' ) );
		add_action( 'wp_ajax_wpimages_webp_clear_logs', array( $this, 'ajax_clear_logs' ) );
	}
	
	/**
	 * Add settings page
	 */
	public function add_settings_page() {
		add_options_page(
			__( 'WebP Converter', 'wpimages-webp' ),
			__( 'WebP Converter', 'wpimages-webp' ),
			'manage_options',
			'wpimages-webp',
			array( $this, 'render_settings_page' )
		);
	}
	
	/**
	 * Register settings
	 */
	public function register_settings() {
		register_setting( 'wpimages_webp_settings', 'wpimages_webp_settings', array(
			'sanitize_callback' => array( $this, 'sanitize_settings' ),
		) );
	}
	
	/**
	 * Sanitize settings
	 */
	public function sanitize_settings( $input ) {
		$sanitized = array();
		
		$sanitized['quality'] = isset( $input['quality'] ) ? absint( $input['quality'] ) : 80;
		$sanitized['quality'] = max( 1, min( 100, $sanitized['quality'] ) );
		
		$sanitized['post_types'] = isset( $input['post_types'] ) && is_array( $input['post_types'] ) 
			? array_map( 'sanitize_key', $input['post_types'] ) 
			: array( 'post', 'page' );
		
		$sanitized['convert_media_library'] = ! empty( $input['convert_media_library'] );
		$sanitized['auto_convert_uploads'] = ! empty( $input['auto_convert_uploads'] );
		$sanitized['auto_convert_on_save'] = ! empty( $input['auto_convert_on_save'] );
		$sanitized['frontend_replacement'] = ! empty( $input['frontend_replacement'] );
		$sanitized['enable_on_archives'] = ! empty( $input['enable_on_archives'] );
		
		$sanitized['conversion_scope'] = isset( $input['conversion_scope'] ) && in_array( $input['conversion_scope'], array( 'all', 'full', 'custom' ), true )
			? $input['conversion_scope']
			: 'all';
			
		$sanitized['conversion_sizes'] = isset( $input['conversion_sizes'] ) && is_array( $input['conversion_sizes'] )
			? array_map( 'sanitize_text_field', $input['conversion_sizes'] )
			: array();
		
		return $sanitized;
	}
	
	/**
	 * Activation notice
	 */
	public function activation_notice() {
		if ( ! get_transient( 'wpimages_webp_activation_notice' ) ) {
			return;
		}
		
		?>
		<div class="notice notice-success is-dismissible">
			<p>
				<strong><?php esc_html_e( 'WPImages WebP Converter activated!', 'wpimages-webp' ); ?></strong>
			</p>
			<p>
				<?php esc_html_e( 'Convert your existing images to WebP for better performance.', 'wpimages-webp' ); ?>
				<a href="<?php echo esc_url( admin_url( 'options-general.php?page=wpimages-webp' ) ); ?>" class="button button-primary" style="margin-left: 10px;">
					<?php esc_html_e( 'Configure Settings', 'wpimages-webp' ); ?>
				</a>
			</p>
		</div>
		<?php
		
		delete_transient( 'wpimages_webp_activation_notice' );
	}
	
	/**
	 * Enqueue admin assets
	 */
	public function enqueue_admin_assets( $hook ) {
		if ( $hook !== 'settings_page_wpimages-webp' ) {
			return;
		}
		
		wp_enqueue_style(
			'wpimages-webp-admin',
			WPIMAGES_WEBP_ASSETS_URL . 'css/admin.css',
			array(),
			WPIMAGES_WEBP_VERSION
		);
		
		wp_enqueue_script(
			'wpimages-webp-admin',
			WPIMAGES_WEBP_ASSETS_URL . 'js/admin.js',
			array( 'jquery' ),
			WPIMAGES_WEBP_VERSION,
			true
		);
		
		wp_enqueue_script(
			'wpimages-webp-batch',
			WPIMAGES_WEBP_ASSETS_URL . 'js/batch-processor.js',
			array( 'jquery', 'wpimages-webp-admin' ),
			WPIMAGES_WEBP_VERSION,
			true
		);
		
		wp_localize_script(
			'wpimages-webp-batch',
			'wpimagesWebpAjax',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'wpimages_webp_batch' ),
				'strings' => array(
					'scanning'   => __( 'Scanning...', 'wpimages-webp' ),
					'converting' => __( 'Converting...', 'wpimages-webp' ),
					'completed'  => __( 'Completed!', 'wpimages-webp' ),
					'error'      => __( 'Error occurred', 'wpimages-webp' ),
				),
			)
		);
	}
	
	/**
	 * AJAX: Scan images
	 */
	public function ajax_scan() {
		check_ajax_referer( 'wpimages_webp_batch', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized', 'wpimages-webp' ) ) );
		}
		
		$scanner = new WPImages_WebP_Scanner();
		$settings = get_option( 'wpimages_webp_settings', array() );
		
		$post_types = isset( $settings['post_types'] ) ? $settings['post_types'] : array( 'post', 'page' );
		$include_media = ! empty( $settings['convert_media_library'] );
		
		// Scan posts
		$post_results = $scanner->scan_posts( $post_types, true );
		
		$total_images = $post_results['total_images'];
		$image_ids = $post_results['image_ids'];
		
		// Scan media library if enabled
		if ( $include_media ) {
			$media_results = $scanner->scan_media_library();
			$image_ids = array_unique( array_merge( $image_ids, $media_results['image_ids'] ) );
			$total_images = count( $image_ids );
		}
		
		wp_send_json_success( array(
			'total_images' => $total_images,
			'total_posts'  => $post_results['total_posts'],
			'post_details' => $post_results['post_details'],
			'image_ids'    => $image_ids,
		) );
	}
	
	/**
	 * AJAX: Clear logs
	 */
	public function ajax_clear_logs() {
		check_ajax_referer( 'wpimages_webp_batch', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized', 'wpimages-webp' ) ) );
		}
		
		wpimages_webp_clear_logs();
		
		wp_send_json_success( array( 'message' => __( 'Logs cleared', 'wpimages-webp' ) ) );
	}
	
	/**
	 * Render settings page - NEW CLEAN VERSION WITH TABS
	 */
	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized', 'wpimages-webp' ) );
		}
		
		// Handle form submission
		if ( isset( $_POST['wpimages_webp_save_settings'] ) ) {
			check_admin_referer( 'wpimages_webp_settings' );
			
			$settings = array();
			$settings['quality'] = isset( $_POST['quality'] ) ? absint( $_POST['quality'] ) : 80;
			$settings['post_types'] = isset( $_POST['post_types'] ) ? array_map( 'sanitize_key', $_POST['post_types'] ) : array();
			$settings['convert_media_library'] = isset( $_POST['convert_media_library'] );
			$settings['auto_convert_uploads'] = isset( $_POST['auto_convert_uploads'] );
			$settings['auto_convert_on_save'] = isset( $_POST['auto_convert_on_save'] );
			$settings['frontend_replacement'] = isset( $_POST['frontend_replacement'] );
			$settings['enable_on_archives'] = isset( $_POST['enable_on_archives'] );
			
			$settings['conversion_scope'] = isset( $_POST['conversion_scope'] ) ? sanitize_key( $_POST['conversion_scope'] ) : 'all';
			$settings['conversion_sizes'] = isset( $_POST['conversion_sizes'] ) && is_array( $_POST['conversion_sizes'] ) 
				? array_map( 'sanitize_text_field', $_POST['conversion_sizes'] ) 
				: array();
			
			update_option( 'wpimages_webp_settings', $settings );
			
			echo '<div class="notice notice-success"><p>' . esc_html__( 'Settings saved!', 'wpimages-webp' ) . '</p></div>';
		}
		
		$settings = get_option( 'wpimages_webp_settings', array() );
		$quality = isset( $settings['quality'] ) ? $settings['quality'] : 80;
		$post_types = isset( $settings['post_types'] ) ? $settings['post_types'] : array( 'post', 'page' );
		$convert_media = ! empty( $settings['convert_media_library'] );
		$auto_uploads = isset( $settings['auto_convert_uploads'] ) ? $settings['auto_convert_uploads'] : true;
		$auto_save = ! empty( $settings['auto_convert_on_save'] );
		$frontend = isset( $settings['frontend_replacement'] ) ? $settings['frontend_replacement'] : true;
		$archives = ! empty( $settings['enable_on_archives'] );
		
		$conversion_scope = isset( $settings['conversion_scope'] ) ? $settings['conversion_scope'] : 'all';
		$conversion_sizes = isset( $settings['conversion_sizes'] ) ? $settings['conversion_sizes'] : array();
		
		$image_editor = wpimages_webp_get_image_editor();
		$last_run = wpimages_webp_get_option( 'last_run', null );
		
		// Include the HTML template
		include WPIMAGES_WEBP_PLUGIN_DIR . 'includes/admin-page-template.php';
	}
}
