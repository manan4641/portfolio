<?php
/**
 * WebP Converter Class
 *
 * @package WPImages_WebP
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles WebP conversion
 */
class WPImages_WebP_Converter {
	
	/**
	 * Convert attachment to WebP
	 *
	 * @param int $attachment_id Attachment ID
	 * @param int $quality Quality (1-100)
	 * @return array Results with success/failure counts
	 */
	public function convert_attachment( $attachment_id, $quality = 80 ) {
		$file = get_attached_file( $attachment_id );
		
		if ( ! $file || ! file_exists( $file ) ) {
			wpimages_webp_log( "Attachment {$attachment_id}: File not found", 'warning' );
			return array( 'success' => 0, 'failed' => 1, 'skipped' => 0 );
		}
		
		$mime = get_post_mime_type( $attachment_id );
		
		// Skip if already WebP
		if ( $mime === 'image/webp' ) {
			wpimages_webp_log( "Attachment {$attachment_id}: Skipped (already WebP)", 'info' );
			return array( 'success' => 0, 'failed' => 0, 'skipped' => 1 );
		}
		
		// Skip if not convertible (not JPG/PNG)
		if ( ! wpimages_webp_is_convertible( $mime ) ) {
			return array( 'success' => 0, 'failed' => 0, 'skipped' => 1 );
		}
		
		$meta  = wp_get_attachment_metadata( $attachment_id );
		$paths = array( $file );
		
		$scope = wpimages_webp_get_option( 'conversion_scope', 'all' );
		$selected_sizes = wpimages_webp_get_option( 'conversion_sizes', array() );
		
		// Get all image sizes
		if ( $scope !== 'full' && ! empty( $meta['sizes'] ) && is_array( $meta['sizes'] ) ) {
			$dir = trailingslashit( pathinfo( $file, PATHINFO_DIRNAME ) );
			foreach ( $meta['sizes'] as $size_name => $size_data ) {
				// If custom scope, check if size is selected
				if ( $scope === 'custom' && ! in_array( $size_name, $selected_sizes, true ) ) {
					continue;
				}
				
				if ( ! empty( $size_data['file'] ) ) {
					$paths[] = $dir . $size_data['file'];
				}
			}
		}
		
		$paths = array_unique( array_filter( $paths ) );
		
		$success = 0;
		$failed = 0;
		$skipped = 0;
		
		foreach ( $paths as $src_path ) {
			$result = $this->convert_image_file( $src_path, $quality );
			
			if ( $result === 'success' ) {
				$success++;
			} elseif ( $result === 'skipped' ) {
				$skipped++;
			} else {
				$failed++;
			}
		}
		
		if ( $success > 0 ) {
			wpimages_webp_log( "Attachment {$attachment_id}: Converted {$success} sizes successfully", 'info' );
		}
		
		return array(
			'success' => $success,
			'failed'  => $failed,
			'skipped' => $skipped,
		);
	}
	
	/**
	 * Convert single image file to WebP
	 *
	 * @param string $file_path Source image path
	 * @param int $quality Quality (1-100)
	 * @return string 'success', 'skipped', or 'failed'
	 */
	public function convert_image_file( $file_path, $quality = 80 ) {
		if ( ! file_exists( $file_path ) ) {
			return 'failed';
		}
		
		// Skip if source file is already WebP
		if ( preg_match( '/\.webp$/i', $file_path ) ) {
			wpimages_webp_log( basename( $file_path ) . ": Skipped (already WebP)", 'info' );
			return 'skipped';
		}
		
		// Generate WebP path
		$webp_path = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $file_path );
		
		if ( ! $webp_path ) {
			return 'failed';
		}
		
		// Skip if WebP already exists
		if ( file_exists( $webp_path ) ) {
			return 'skipped';
		}
		
		// Use WordPress image editor
		$editor = wp_get_image_editor( $file_path );
		
		if ( is_wp_error( $editor ) ) {
			wpimages_webp_log( "Failed to load editor for {$file_path}: " . $editor->get_error_message(), 'error' );
			return 'failed';
		}
		
		// Set quality
		if ( method_exists( $editor, 'set_quality' ) ) {
			$editor->set_quality( absint( $quality ) );
		}
		
		// Save as WebP
		$saved = $editor->save( $webp_path, 'image/webp' );
		
		if ( is_wp_error( $saved ) ) {
			wpimages_webp_log( "Failed to save WebP for {$file_path}: " . $saved->get_error_message(), 'error' );
			return 'failed';
		}
		
		// Log file size comparison
		$original_size = filesize( $file_path );
		$webp_size = filesize( $webp_path );
		$savings = $original_size - $webp_size;
		$savings_percent = round( ( $savings / $original_size ) * 100, 2 );
		
		wpimages_webp_log( 
			basename( $file_path ) . " -> " . basename( $webp_path ) . 
			" ({$savings_percent}% smaller, saved " . wpimages_webp_format_bytes( $savings ) . ")", 
			'info' 
		);
		
		return 'success';
	}
	
	/**
	 * Batch convert multiple attachments
	 *
	 * @param array $attachment_ids Array of attachment IDs
	 * @param int $quality Quality (1-100)
	 * @return array Summary with counts
	 */
	public function batch_convert( $attachment_ids, $quality = 80 ) {
		$total_success = 0;
		$total_failed = 0;
		$total_skipped = 0;
		
		foreach ( $attachment_ids as $attachment_id ) {
			$result = $this->convert_attachment( $attachment_id, $quality );
			
			$total_success += $result['success'];
			$total_failed += $result['failed'];
			$total_skipped += $result['skipped'];
		}
		
		return array(
			'total'   => count( $attachment_ids ),
			'success' => $total_success,
			'failed'  => $total_failed,
			'skipped' => $total_skipped,
		);
	}
	
	/**
	 * Get image editor type
	 *
	 * @return string
	 */
	public function get_image_editor_type() {
		return wpimages_webp_get_image_editor();
	}
}
