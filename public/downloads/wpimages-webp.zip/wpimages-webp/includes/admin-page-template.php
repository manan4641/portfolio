<?php
/**
 * Admin Page Template - Tabbed Interface
 *
 * @package WPImages_WebP
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="wrap wpimages-webp-admin">
	<h1><?php esc_html_e( 'WebP Converter Settings', 'wpimages-webp' ); ?></h1>
	
	<?php if ( $image_editor === 'none' ) : ?>
		<div class="notice notice-error">
			<p>
				<strong><?php esc_html_e( 'Warning:', 'wpimages-webp' ); ?></strong>
				<?php esc_html_e( 'No WebP-compatible image editor found. Please install GD or Imagick PHP extension.', 'wpimages-webp' ); ?>
			</p>
		</div>
	<?php else : ?>
		<div class="notice notice-info">
			<p>
				<strong><?php esc_html_e( 'Image Editor:', 'wpimages-webp' ); ?></strong>
				<?php echo esc_html( ucfirst( $image_editor ) ); ?>
			</p>
		</div>
	<?php endif; ?>
	
	<!-- Tab Navigation -->
	<div class="wpimages-tabs">
		<div class="wpimages-tab active" data-tab="settings-panel">
			<span class="dashicons dashicons-admin-generic"></span> <?php esc_html_e( 'Settings', 'wpimages-webp' ); ?>
		</div>
		<div class="wpimages-tab" data-tab="guide-panel">
			<span class="dashicons dashicons-info"></span> <?php esc_html_e( 'How It Works', 'wpimages-webp' ); ?>
		</div>
		<div class="wpimages-tab" data-tab="conversion-panel">
			<span class="dashicons dashicons-update"></span> <?php esc_html_e( 'Batch Conversion', 'wpimages-webp' ); ?>
		</div>
		<div class="wpimages-tab" data-tab="logs-panel">
			<span class="dashicons dashicons-media-text"></span> <?php esc_html_e( 'Logs', 'wpimages-webp' ); ?>
		</div>
	</div>
	
	<!-- Settings Panel -->
	<div id="settings-panel" class="wpimages-tab-panel active">
		<div class="wpimages-webp-container">
			<form method="post" action="">
				<?php wp_nonce_field( 'wpimages_webp_settings' ); ?>
				
				<table class="form-table">
					<tr>
						<th scope="row">
							<label for="quality"><?php esc_html_e( 'WebP Quality', 'wpimages-webp' ); ?></label>
						</th>
						<td>
							<input type="range" id="quality" name="quality" min="1" max="100" value="<?php echo esc_attr( $quality ); ?>" class="wpimages-quality-slider">
							<span class="wpimages-quality-value"><?php echo esc_html( $quality ); ?></span>
							<p class="description">
								<?php esc_html_e( 'Higher quality = larger file size. Recommended: 75-85', 'wpimages-webp' ); ?>
							</p>
						</td>
					</tr>
					
					<tr>
						<th scope="row"><?php esc_html_e( 'Convert Post Types', 'wpimages-webp' ); ?></th>
						<td>
							<?php
							$available_post_types = get_post_types( array( 'public' => true ), 'objects' );
							foreach ( $available_post_types as $pt ) {
								if ( in_array( $pt->name, array( 'attachment', 'revision', 'nav_menu_item' ), true ) ) {
								}
								?>
								<label style="display: block; margin-bottom: 5px;">
									<input type="checkbox" name="post_types[]" value="<?php echo esc_attr( $pt->name ); ?>" <?php checked( in_array( $pt->name, $post_types, true ) ); ?>>
									<?php echo esc_html( $pt->label ); ?>
								</label>
								<?php
							}
							?>
							<p class="description">
								<?php esc_html_e( 'Select which post types to scan for images. Custom post types (Projects, Products, etc.) are automatically detected.', 'wpimages-webp' ); ?>
							</p>
						</td>
					</tr>
					
					<tr>
						<th scope="row"><?php esc_html_e( 'Images to Convert', 'wpimages-webp' ); ?></th>
						<td>
							<fieldset>
								<label style="display: block; margin-bottom: 5px;">
									<input type="radio" name="conversion_scope" value="all" <?php checked( $conversion_scope, 'all' ); ?>>
									<?php esc_html_e( 'All image sizes (default)', 'wpimages-webp' ); ?>
								</label>
								
								<label style="display: block; margin-bottom: 5px;">
									<input type="radio" name="conversion_scope" value="full" <?php checked( $conversion_scope, 'full' ); ?>>
									<?php esc_html_e( 'Full size only', 'wpimages-webp' ); ?>
								</label>
								
								<label style="display: block; margin-bottom: 5px;">
									<input type="radio" name="conversion_scope" value="custom" <?php checked( $conversion_scope, 'custom' ); ?>>
									<?php esc_html_e( 'Full size + selected sizes', 'wpimages-webp' ); ?>
								</label>
								
								<div id="wpimages-custom-sizes" style="margin-left: 20px; margin-top: 10px; padding: 10px; background: #f9f9f9; border: 1px solid #ddd; max-height: 200px; overflow-y: auto;">
									<p class="description" style="margin-top: 0; margin-bottom: 10px;">
										<?php esc_html_e( 'Select additional sizes to convert:', 'wpimages-webp' ); ?>
									</p>
									<?php
									$all_sizes = wpimages_webp_get_all_image_sizes();
									foreach ( $all_sizes as $slug => $data ) { ?>
										<label style="display: block; margin-bottom: 5px;">
											<input type="checkbox" name="conversion_sizes[]" value="<?php echo esc_attr( $slug ); ?>" <?php checked( in_array( $slug, $conversion_sizes, true ) ); ?>>
											<?php echo esc_html( $data['name'] ); ?> 
											<span style="color: #666; font-size: 12px;">(<?php echo esc_html( $data['width'] . 'x' . $data['height'] ); ?>)</span>
										</label>
										<?php
									}
									?>
									<p class="description" style="margin-top: 10px;">
										<strong><?php esc_html_e( 'Note:', 'wpimages-webp' ); ?></strong>
										<?php esc_html_e( 'Converting more sizes increases storage usage because WebP files are created in addition to the original JPG/PNG files.', 'wpimages-webp' ); ?>
									</p>
								</div>
							</fieldset>
						</td>
					</tr>
					
					<tr>
						<th scope="row"><?php esc_html_e( 'Additional Options', 'wpimages-webp' ); ?></th>
						<td>
							<label style="display: block; margin-bottom: 10px;">
								<input type="checkbox" name="convert_media_library" value="1" <?php checked( $convert_media, true ); ?>>
								<?php esc_html_e( 'Also convert entire Media Library (includes unused images)', 'wpimages-webp' ); ?>
							</label>
							
							<label style="display: block; margin-bottom: 10px;">
								<input type="checkbox" name="auto_convert_uploads" value="1" <?php checked( $auto_uploads, true ); ?>>
								<?php esc_html_e( 'Auto-convert new uploads to WebP', 'wpimages-webp' ); ?>
							</label>
							
							<label style="display: block; margin-bottom: 10px;">
								<input type="checkbox" name="auto_convert_on_save" value="1" <?php checked( $auto_save, true ); ?>>
								<?php esc_html_e( 'Auto-convert images when saving posts (may slow down save operation)', 'wpimages-webp' ); ?>
							</label>
							
							<label style="display: block; margin-bottom: 10px;">
								<input type="checkbox" name="frontend_replacement" value="1" <?php checked( $frontend, true ); ?>>
								<?php esc_html_e( 'Enable frontend WebP replacement', 'wpimages-webp' ); ?>
							</label>
							
							<label style="display: block; margin-bottom: 10px;">
								<input type="checkbox" name="enable_on_archives" value="1" <?php checked( $archives, true ); ?>>
								<?php esc_html_e( 'Enable WebP on archive pages', 'wpimages-webp' ); ?>
							</label>
						</td>
					</tr>
				</table>
				
				<p class="submit">
					<input type="submit" name="wpimages_webp_save_settings" class="button button-primary" value="<?php esc_attr_e( 'Save Settings', 'wpimages-webp' ); ?>">
				</p>
			</form>
		</div>
	</div>
	
	<!-- How It Works Guide Panel -->
	<div id="guide-panel" class="wpimages-tab-panel">
		<?php include WPIMAGES_WEBP_PLUGIN_DIR . 'includes/guide-content.php'; ?>
	</div>
	
	<!-- Batch Conversion Panel -->
	<div id="conversion-panel" class="wpimages-tab-panel">
		<div class="wpimages-webp-container">
			<div class="wpimages-webp-batch">
				<h2><?php esc_html_e( 'Batch Conversion', 'wpimages-webp' ); ?></h2>
				
				<div class="wpimages-notice wpimages-notice-warning">
					<p>
						<strong><?php esc_html_e( 'Important:', 'wpimages-webp' ); ?></strong>
						<?php esc_html_e( 'This will create WebP versions of your images. Original images will be kept. Make sure you have a backup before proceeding.', 'wpimages-webp' ); ?>
					</p>
				</div>
				
				<div class="wpimages-scan-section">
					<button type="button" id="wpimages-scan-btn" class="button button-large">
						<?php esc_html_e( 'Scan Images', 'wpimages-webp' ); ?>
					</button>
					<div id="wpimages-scan-results" style="margin-top: 20px;"></div>
				</div>
				
				<div id="wpimages-convert-section" style="display: none; margin-top: 30px;">
					<button type="button" id="wpimages-convert-btn" class="button button-primary button-large">
						<?php esc_html_e( 'Convert to WebP', 'wpimages-webp' ); ?>
					</button>
					
					<div id="wpimages-progress-container" style="display: none; margin-top: 20px;">
						<div class="wpimages-progress-bar">
							<div class="wpimages-progress-fill"></div>
							<div class="wpimages-progress-text">0%</div>
						</div>
						<div id="wpimages-progress-status" style="margin-top: 10px;"></div>
					</div>
					
					<div id="wpimages-conversion-results" style="margin-top: 20px;"></div>
				</div>
				
				<?php if ( $last_run ) : ?>
					<div class="wpimages-last-run" style="margin-top: 30px; padding: 15px; background: #f5f5f5; border-left: 4px solid #2271b1;">
						<h3><?php esc_html_e( 'Last Conversion Run', 'wpimages-webp' ); ?></h3>
						<p>
							<strong><?php esc_html_e( 'Completed:', 'wpimages-webp' ); ?></strong>
							<?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $last_run['completed'] ) ); ?>
						</p>
						<p>
							<strong><?php esc_html_e( 'Results:', 'wpimages-webp' ); ?></strong>
							<?php

							/* translators: 1: Number of successful conversions, 2: Number of failed conversions, 3: Number of skipped conversions */
							$result_message = __( '%1$d successful, %2$d failed, %3$d skipped', 'wpimages-webp' );
							printf(
								esc_html( $result_message ),
								intval( $last_run['success'] ),
								intval( $last_run['failed'] ),
								intval( $last_run['skipped'] )
							);
							?>
						</p>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
	
	<!-- Logs Panel -->
	<div id="logs-panel" class="wpimages-tab-panel">
		<div class="wpimages-webp-container">
			<div class="wpimages-webp-logs">
				<h2><?php esc_html_e( 'Conversion Logs', 'wpimages-webp' ); ?></h2>
				<p>
					<button type="button" id="wpimages-view-logs-btn" class="button">
						<?php esc_html_e( 'View Logs', 'wpimages-webp' ); ?>
					</button>
					<button type="button" id="wpimages-clear-logs-btn" class="button">
						<?php esc_html_e( 'Clear Logs', 'wpimages-webp' ); ?>
					</button>
				</p>
				<div id="wpimages-logs-content" style="display: none; margin-top: 15px;">
					<pre style="background: #f5f5f5; padding: 15px; max-height: 400px; overflow-y: auto; font-size: 12px;"><?php echo esc_html( wpimages_webp_get_log( 200 ) ); ?></pre>
				</div>
			</div>
		</div>
	</div>
	
</div>
