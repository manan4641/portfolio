<?php
/**
 * Scanner Class
 *
 * @package WPImages_WebP
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Scans posts and pages for images
 */
class WPImages_WebP_Scanner {
	
	/**
	 * Scan posts for images
	 *
	 * @param array $post_types Post types to scan
	 * @param bool $dry_run True for preview mode
	 * @return array Scan results
	 */
	public function scan_posts( $post_types = array( 'post', 'page' ), $dry_run = false ) {
		$all_images = array();
		$post_count = 0;
		$post_details = array();
		
		$args = array(
			'post_type'      => $post_types,
			'post_status'    => array( 'publish', 'draft' ),
			'posts_per_page' => -1,
			'fields'         => 'ids',
		);
		
		$query = new WP_Query( $args );
		
		if ( $query->have_posts() ) {
			foreach ( $query->posts as $post_id ) {
				$images = $this->get_images_from_post( $post_id );
				
				if ( ! empty( $images ) ) {
					$all_images = array_merge( $all_images, $images );
					$post_count++;
					
					if ( $dry_run ) {
						$post_details[] = array(
							'id'         => $post_id,
							'title'      => get_the_title( $post_id ),
							'type'       => get_post_type( $post_id ),
							'image_count' => count( $images ),
						);
					}
				}
			}
		}
		
		$all_images = array_values( array_unique( $all_images ) );
		
		return array(
			'total_images' => count( $all_images ),
			'total_posts'  => $post_count,
			'image_ids'    => $all_images,
			'post_details' => $post_details,
		);
	}
	
	/**
	 * Get images from a single post
	 *
	 * @param int $post_id Post ID
	 * @return array Array of attachment IDs
	 */
	public function get_images_from_post( $post_id ) {
		$ids = array();
		$post = get_post( $post_id );
		
		if ( ! $post ) {
			return $ids;
		}
		
		// Featured image
		$thumb_id = get_post_thumbnail_id( $post_id );
		if ( $thumb_id ) {
			$ids[] = (int) $thumb_id;
		}
		
		// Gutenberg blocks
		$blocks = parse_blocks( $post->post_content );
		$this->collect_ids_from_blocks( $blocks, $ids );
		
		// Classic editor images
		$this->collect_ids_from_html( $post->post_content, $ids );
		
		// Elementor content
		if ( class_exists( 'Elementor\Plugin' ) ) {
			$this->collect_ids_from_elementor( $post_id, $ids );
		}
		
		// Remove duplicates
		$ids = array_values( array_unique( array_filter( $ids ) ) );
		
		// IMPORTANT: Filter out WebP images from final count
		$filtered_ids = array();
		foreach ( $ids as $attachment_id ) {
			$mime = get_post_mime_type( $attachment_id );
			// Only include JPG/PNG images (exclude WebP and other formats)
			if ( in_array( $mime, array( 'image/jpeg', 'image/png' ), true ) ) {
				$filtered_ids[] = $attachment_id;
			}
		}
		
		return $filtered_ids;
	}
	
	/**
	 * Collect attachment IDs from Gutenberg blocks
	 *
	 * @param array $blocks Blocks array
	 * @param array &$ids Reference to IDs array
	 */
	private function collect_ids_from_blocks( $blocks, &$ids ) {
		if ( empty( $blocks ) || ! is_array( $blocks ) ) {
			return;
		}
		
		foreach ( $blocks as $block ) {
			if ( empty( $block['blockName'] ) ) {
				continue;
			}
			
			// Image block
			if ( $block['blockName'] === 'core/image' && ! empty( $block['attrs']['id'] ) ) {
				$ids[] = (int) $block['attrs']['id'];
			}
			
			// Gallery block
			if ( $block['blockName'] === 'core/gallery' && ! empty( $block['attrs']['ids'] ) && is_array( $block['attrs']['ids'] ) ) {
				foreach ( $block['attrs']['ids'] as $id ) {
					$ids[] = (int) $id;
				}
			}
			
			// Cover block
			if ( $block['blockName'] === 'core/cover' && ! empty( $block['attrs']['id'] ) ) {
				$ids[] = (int) $block['attrs']['id'];
			}
			
			// Media & Text block
			if ( $block['blockName'] === 'core/media-text' && ! empty( $block['attrs']['mediaId'] ) ) {
				$ids[] = (int) $block['attrs']['mediaId'];
			}
			
			// Recursively check inner blocks
			if ( ! empty( $block['innerBlocks'] ) ) {
				$this->collect_ids_from_blocks( $block['innerBlocks'], $ids );
			}
		}
	}
	
	/**
	 * Collect attachment IDs from HTML content
	 *
	 * @param string $content HTML content
	 * @param array &$ids Reference to IDs array
	 */
	private function collect_ids_from_html( $content, &$ids ) {
		// Extract img tags
		if ( preg_match_all( '#<img[^>]+src=["\']([^"\']+)["\']#i', $content, $matches ) ) {
			foreach ( $matches[1] as $url ) {
				$att_id = attachment_url_to_postid( $url );
				if ( $att_id ) {
					$ids[] = (int) $att_id;
				}
			}
		}
		
		// Extract wp-image-XXX classes
		if ( preg_match_all( '/wp-image-(\d+)/i', $content, $matches ) ) {
			foreach ( $matches[1] as $id ) {
				$ids[] = (int) $id;
			}
		}
	}
	
	/**
	 * Collect attachment IDs from Elementor data
	 *
	 * @param int $post_id Post ID
	 * @param array &$ids Reference to IDs array
	 */
	private function collect_ids_from_elementor( $post_id, &$ids ) {
		$el_data = get_post_meta( $post_id, '_elementor_data', true );
		
		if ( empty( $el_data ) ) {
			return;
		}
		
		$decoded = json_decode( $el_data, true );
		
		if ( is_array( $decoded ) ) {
			$this->collect_ids_from_elementor_value( $decoded, $ids );
		}
	}
	
	/**
	 * Recursively collect IDs from Elementor data structure
	 *
	 * @param mixed $value Elementor data value
	 * @param array &$ids Reference to IDs array
	 */
	private function collect_ids_from_elementor_value( $value, &$ids ) {
		if ( is_array( $value ) ) {
			
			// Check for direct ID field
			if ( isset( $value['id'] ) && is_numeric( $value['id'] ) ) {
				$maybe_id = (int) $value['id'];
				$mime = get_post_mime_type( $maybe_id );
				// Exclude WebP images
				if ( $maybe_id > 0 && strpos( (string) $mime, 'image/' ) === 0 && $mime !== 'image/webp' ) {
					$ids[] = $maybe_id;
				}
			}
			
			foreach ( $value as $key => $v ) {
				if ( is_array( $v ) ) {
					// Check if it's a flat array of numeric IDs (gallery)
					$all_numeric = ! empty( $v );
					foreach ( $v as $vv ) {
						if ( is_array( $vv ) || ! is_numeric( $vv ) ) {
							$all_numeric = false;
							break;
						}
					}
					
					if ( $all_numeric ) {
						foreach ( $v as $att_id ) {
							$att_id = (int) $att_id;
							$mime = get_post_mime_type( $att_id );
							// Exclude WebP images
							if ( $att_id > 0 && strpos( (string) $mime, 'image/' ) === 0 && $mime !== 'image/webp' ) {
								$ids[] = $att_id;
							}
						}
					} else {
						$this->collect_ids_from_elementor_value( $v, $ids );
					}
				} else {
					// Check if it's a URL (exclude .webp URLs)
					if ( is_string( $v ) && strpos( $v, '/uploads/' ) !== false && preg_match( '/\.(jpe?g|png)$/i', $v ) ) {
						$att_id = attachment_url_to_postid( $v );
						if ( $att_id ) {
							$ids[] = (int) $att_id;
						}
					}
				}
			}
		}
	}
	
	/**
	 * Scan media library
	 *
	 * @return array Scan results
	 */
	public function scan_media_library() {
		$args = array(
			'post_type'      => 'attachment',
			'post_mime_type' => array( 'image/jpeg', 'image/png' ), // Excludes WebP
			'post_status'    => 'inherit',
			'posts_per_page' => -1,
			'fields'         => 'ids',
		);
		
		$query = new WP_Query( $args );
		
		return array(
			'total_images' => count( $query->posts ),
			'image_ids'    => $query->posts,
		);
	}
}
