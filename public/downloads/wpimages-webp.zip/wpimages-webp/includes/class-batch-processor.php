<?php
/**
 * Batch Processor Class
 *
 * @package WPImages_WebP
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles AJAX batch processing
 */
class WPImages_WebP_Batch_Processor {
	
	/**
	 * Single instance
	 */
	private static $instance = null;
	
	/**
	 * Batch size (images per request)
	 */
	private $batch_size = 20;
	
	/**
	 * Get instance
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'wp_ajax_wpimages_webp_start_batch', array( $this, 'ajax_start_batch' ) );
		add_action( 'wp_ajax_wpimages_webp_process_batch', array( $this, 'ajax_process_batch' ) );
		add_action( 'wp_ajax_wpimages_webp_get_progress', array( $this, 'ajax_get_progress' ) );
	}
	
	/**
	 * AJAX: Start batch conversion
	 */
	public function ajax_start_batch() {
		// Security checks
		check_ajax_referer( 'wpimages_webp_batch', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized', 'wpimages-webp' ) ) );
		}
		
		// Get scan results from request
		$image_ids = isset( $_POST['image_ids'] ) ? array_map( 'absint', $_POST['image_ids'] ) : array();
		
		if ( empty( $image_ids ) ) {
			wp_send_json_error( array( 'message' => __( 'No images to convert', 'wpimages-webp' ) ) );
		}
		
		// Store queue in transient (1 hour expiration)
		$user_id = get_current_user_id();
		$progress_key = 'wpimages_webp_progress_' . $user_id;
		
		$progress_data = array(
			'total'     => count( $image_ids ),
			'processed' => 0,
			'success'   => 0,
			'failed'    => 0,
			'skipped'   => 0,
			'queue'     => $image_ids,
			'status'    => 'processing',
			'started'   => time(),
		);
		
		set_transient( $progress_key, $progress_data, HOUR_IN_SECONDS );
		
		wpimages_webp_log( 'Batch conversion started: ' . count( $image_ids ) . ' images', 'info' );
		
		wp_send_json_success( array(
			'message' => __( 'Batch conversion started', 'wpimages-webp' ),
			'total'   => count( $image_ids ),
		) );
	}
	
	/**
	 * AJAX: Process batch chunk
	 */
	public function ajax_process_batch() {
		// Security checks
		check_ajax_referer( 'wpimages_webp_batch', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized', 'wpimages-webp' ) ) );
		}
		
		// Get progress data
		$user_id = get_current_user_id();
		$progress_key = 'wpimages_webp_progress_' . $user_id;
		$progress = get_transient( $progress_key );
		
		if ( ! $progress || empty( $progress['queue'] ) ) {
			wp_send_json_error( array( 'message' => __( 'No batch in progress', 'wpimages-webp' ) ) );
		}
		
		// Process next batch
		$batch = array_splice( $progress['queue'], 0, $this->batch_size );
		$quality = wpimages_webp_get_option( 'quality', 80 );
		
		$converter = new WPImages_WebP_Converter();
		
		foreach ( $batch as $attachment_id ) {
			$result = $converter->convert_attachment( $attachment_id, $quality );
			
			$progress['processed']++;
			$progress['success'] += $result['success'];
			$progress['failed'] += $result['failed'];
			$progress['skipped'] += $result['skipped'];
		}
		
		// Update or complete
		if ( empty( $progress['queue'] ) ) {
			$progress['status'] = 'completed';
			$progress['completed'] = time();
			
			// Store final results
			wpimages_webp_update_option( 'last_run', $progress );
			
			wpimages_webp_log( 
				sprintf( 
					'Batch conversion completed: %d successful, %d failed, %d skipped',
					$progress['success'],
					$progress['failed'],
					$progress['skipped']
				),
				'info'
			);
		}
		
		set_transient( $progress_key, $progress, HOUR_IN_SECONDS );
		
		wp_send_json_success( array(
			'total'     => $progress['total'],
			'processed' => $progress['processed'],
			'success'   => $progress['success'],
			'failed'    => $progress['failed'],
			'skipped'   => $progress['skipped'],
			'status'    => $progress['status'],
			'percent'   => round( ( $progress['processed'] / $progress['total'] ) * 100, 2 ),
		) );
	}
	
	/**
	 * AJAX: Get progress
	 */
	public function ajax_get_progress() {
		// Security checks
		check_ajax_referer( 'wpimages_webp_batch', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized', 'wpimages-webp' ) ) );
		}
		
		// Get progress
		$user_id = get_current_user_id();
		$progress_key = 'wpimages_webp_progress_' . $user_id;
		$progress = get_transient( $progress_key );
		
		if ( ! $progress ) {
			wp_send_json_error( array( 'message' => __( 'No batch in progress', 'wpimages-webp' ) ) );
		}
		
		wp_send_json_success( array(
			'total'     => $progress['total'],
			'processed' => $progress['processed'],
			'success'   => $progress['success'],
			'failed'    => $progress['failed'],
			'skipped'   => $progress['skipped'],
			'status'    => $progress['status'],
			'percent'   => round( ( $progress['processed'] / $progress['total'] ) * 100, 2 ),
		) );
	}
}
