<?php
/**
 * Helper functions
 *
 * @package WPImages_WebP
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get plugin option
 *
 * @param string $key Option key
 * @param mixed $default Default value
 * @return mixed
 */
function wpimages_webp_get_option( $key, $default = null ) {
	$settings = get_option( 'wpimages_webp_settings', array() );
	
	if ( isset( $settings[ $key ] ) ) {
		return $settings[ $key ];
	}
	
	return $default;
}

/**
 * Update plugin option
 *
 * @param string $key Option key
 * @param mixed $value Option value
 * @return bool
 */
function wpimages_webp_update_option( $key, $value ) {
	$settings = get_option( 'wpimages_webp_settings', array() );
	$settings[ $key ] = $value;
	
	return update_option( 'wpimages_webp_settings', $settings );
}

/**
 * Convert URL to file path
 *
 * @param string $url Image URL
 * @return string|false File path or false if not in uploads directory
 */
function wpimages_webp_url_to_path( $url ) {
	$uploads = wp_get_upload_dir();
	
	if ( empty( $uploads['baseurl'] ) || empty( $uploads['basedir'] ) ) {
		return false;
	}
	
	// Check if URL is in uploads directory
	if ( strpos( $url, $uploads['baseurl'] ) === false ) {
		return false;
	}
	
	$path = str_replace( $uploads['baseurl'], $uploads['basedir'], $url );
	
	// Security: Ensure path is within uploads directory
	$real_path = realpath( dirname( $path ) );
	$real_uploads = realpath( $uploads['basedir'] );
	
	if ( $real_path && $real_uploads && strpos( $real_path, $real_uploads ) === 0 ) {
		return $path;
	}
	
	return false;
}

/**
 * Swap image URL to WebP if exists
 *
 * @param string $url Original image URL
 * @return string WebP URL if exists, original URL otherwise
 */
function wpimages_webp_swap_url( $url ) {
	if ( ! is_string( $url ) || $url === '' ) {
		return $url;
	}
	
	// Already WebP
	if ( preg_match( '/\.webp(\?|$)/i', $url ) ) {
		return $url;
	}
	
	// Not a convertible image
	if ( ! preg_match( '/\.(jpe?g|png)(\?|$)/i', $url ) ) {
		return $url;
	}
	
	$uploads = wp_get_upload_dir();
	if ( empty( $uploads['baseurl'] ) || empty( $uploads['basedir'] ) ) {
		return $url;
	}
	
	// Only touch uploads URLs
	if ( strpos( $url, $uploads['baseurl'] ) === false ) {
		return $url;
	}
	
	$webp_url  = preg_replace( '/\.(jpe?g|png)(\?|$)/i', '.webp$2', $url );
	
	// Remove query string for file path check
	$webp_url_clean = strtok( $webp_url, '?' );
	$webp_path = str_replace( $uploads['baseurl'], $uploads['basedir'], $webp_url_clean );
	
	return file_exists( $webp_path ) ? $webp_url : $url;
}

/**
 * Check if image MIME type is convertible
 *
 * @param string $mime MIME type
 * @return bool
 */
function wpimages_webp_is_convertible( $mime ) {
	return in_array( $mime, array( 'image/jpeg', 'image/png' ), true );
}

/**
 * Log message
 *
 * @param string $message Log message
 * @param string $level Log level (info, warning, error)
 * @return bool
 */
function wpimages_webp_log( $message, $level = 'info' ) {
	$uploads = wp_get_upload_dir();
	$log_dir = $uploads['basedir'] . '/wpimages-webp';
	
	// Create log directory if it doesn't exist
	if ( ! file_exists( $log_dir ) ) {
		wp_mkdir_p( $log_dir );
		
		// Add .htaccess to protect logs
		$htaccess_file = $log_dir . '/.htaccess';
		if ( ! file_exists( $htaccess_file ) ) {
			file_put_contents( $htaccess_file, "Deny from all\n" );
		}
	}
	
	$log_file = $log_dir . '/conversion.log';
	
	// Rotate log if too large (5MB)
	if ( file_exists( $log_file ) && filesize( $log_file ) > 5 * 1024 * 1024 ) {
		global $wp_filesystem;
		if ( empty( $wp_filesystem ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}
		if ( $wp_filesystem ) {
			$wp_filesystem->move( $log_file, $log_dir . '/conversion-' . time() . '.log' );
		}
	}
	
	$timestamp = current_time( 'Y-m-d H:i:s' );
	$level = strtoupper( $level );
	$log_entry = "[{$timestamp}] [{$level}] {$message}\n";
	
	return file_put_contents( $log_file, $log_entry, FILE_APPEND | LOCK_EX ) !== false;
}

/**
 * Get available image editor type
 *
 * @return string 'imagick', 'gd', or 'none'
 */
function wpimages_webp_get_image_editor() {
	// Check Imagick
	if ( extension_loaded( 'imagick' ) && class_exists( 'Imagick' ) ) {
		$imagick = new Imagick();
		if ( in_array( 'WEBP', $imagick->queryFormats(), true ) ) {
			return 'imagick';
		}
	}
	
	// Check GD
	if ( function_exists( 'imagewebp' ) ) {
		return 'gd';
	}
	
	return 'none';
}

/**
 * Format file size
 *
 * @param int $bytes File size in bytes
 * @return string Formatted size
 */
function wpimages_webp_format_bytes( $bytes ) {
	if ( $bytes >= 1073741824 ) {
		return number_format( $bytes / 1073741824, 2 ) . ' GB';
	} elseif ( $bytes >= 1048576 ) {
		return number_format( $bytes / 1048576, 2 ) . ' MB';
	} elseif ( $bytes >= 1024 ) {
		return number_format( $bytes / 1024, 2 ) . ' KB';
	} else {
		return $bytes . ' bytes';
	}
}

/**
 * Get log file contents
 *
 * @param int $lines Number of lines to retrieve (from end)
 * @return string
 */
function wpimages_webp_get_log( $lines = 100 ) {
	$uploads = wp_get_upload_dir();
	$log_file = $uploads['basedir'] . '/wpimages-webp/conversion.log';
	
	if ( ! file_exists( $log_file ) ) {
		return __( 'No logs available.', 'wpimages-webp' );
	}
	
	$file = file( $log_file );
	$file = array_reverse( $file );
	$file = array_slice( $file, 0, $lines );
	$file = array_reverse( $file );
	
	return implode( '', $file );
}

/**
 * Clear log files
 *
 * @return bool
 */
function wpimages_webp_clear_logs() {
	$uploads = wp_get_upload_dir();
	$log_dir = $uploads['basedir'] . '/wpimages-webp';
	
	if ( ! file_exists( $log_dir ) ) {
		return true;
	}
	
	$files = glob( $log_dir . '/*.log' );
	foreach ( $files as $file ) {
		if ( is_file( $file ) ) {
			wp_delete_file( $file );
		}
	}
	
	return true;
}

/**
 * Get all registered image sizes
 *
 * @return array [slug => [width, height, name]]
 */
function wpimages_webp_get_all_image_sizes() {
	global $_wp_additional_image_sizes;
	
	$sizes = array();
	$default_sizes = array( 'thumbnail', 'medium', 'medium_large', 'large', '1536x1536', '2048x2048' );
	
	foreach ( $default_sizes as $size ) {
		$sizes[ $size ] = array(
			'width'  => intval( get_option( "{$size}_size_w" ) ),
			'height' => intval( get_option( "{$size}_size_h" ) ),
			'name'   => ucfirst( str_replace( '_', ' ', $size ) ),
		);
	}
	
	if ( ! empty( $_wp_additional_image_sizes ) ) {
		foreach ( $_wp_additional_image_sizes as $slug => $data ) {
			$sizes[ $slug ] = array(
				'width'  => isset( $data['width'] ) ? intval( $data['width'] ) : 0,
				'height' => isset( $data['height'] ) ? intval( $data['height'] ) : 0,
				'name'   => ucfirst( str_replace( array( '-', '_' ), ' ', $slug ) ),
			);
		}
	}
	
	return $sizes;
}
