<?php
/**
 * Frontend Class
 *
 * @package WPImages_WebP
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles frontend WebP URL replacement
 */
class WPImages_WebP_Frontend {
	
	/**
	 * Single instance
	 */
	private static $instance = null;
	
	/**
	 * Get instance
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		// Check if frontend replacement is enabled
		if ( ! wpimages_webp_get_option( 'frontend_replacement', true ) ) {
			return;
		}
		
		// Content filters
		add_filter( 'the_content', array( $this, 'replace_content_urls' ), 999 );
		add_filter( 'post_thumbnail_html', array( $this, 'replace_content_urls' ), 999 );
		add_filter( 'wp_get_attachment_image_src', array( $this, 'replace_attachment_url' ), 999 );
		add_filter( 'wp_calculate_image_srcset', array( $this, 'replace_srcset_urls' ), 999 );
		
		// Elementor support
		if ( class_exists( 'Elementor\Plugin' ) ) {
			add_filter( 'elementor/frontend/the_content', array( $this, 'replace_content_urls' ), 20 );
		}
		
		// Enqueue background image swap JavaScript
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ), 999 );
	}
	
	/**
	 * Replace URLs in content
	 *
	 * @param string $content Content
	 * @return string Modified content
	 */
	public function replace_content_urls( $content ) {
		if ( ! is_string( $content ) || empty( $content ) ) {
			return $content;
		}
		
		// Replace image URLs in HTML attributes and CSS url()
		$content = preg_replace_callback(
			'~' .
			'(?:(src|href|srcset|data-[a-z0-9\-_]+)=([\'"])([^\'\"]+)\2)' .
			'|' .
			'(url\((?:[\'"])?)([^\'\)]+)((?:[\'"])?\))' .
			'~i',
			function( $m ) {
				// HTML attribute
				if ( ! empty( $m[3] ) ) {
					$new = $this->replace_url_or_srcset( $m[3] );
					return $m[1] . '=' . $m[2] . $new . $m[2];
				}
				// CSS url()
				if ( ! empty( $m[5] ) ) {
					$new = wpimages_webp_swap_url( $m[5] );
					return $m[4] . $new . $m[6];
				}
				return $m[0];
			},
			$content
		);
		
		return $content;
	}
	
	/**
	 * Replace URL or srcset
	 *
	 * @param string $value URL or srcset string
	 * @return string Modified value
	 */
	private function replace_url_or_srcset( $value ) {
		// Check if it's a srcset (contains commas and descriptors)
		if ( strpos( $value, ',' ) !== false && preg_match( '/\s+\d+[wx]/i', $value ) ) {
			return $this->replace_srcset_string( $value );
		}
		
		return wpimages_webp_swap_url( $value );
	}
	
	/**
	 * Replace URLs in srcset string
	 *
	 * @param string $srcset Srcset string
	 * @return string Modified srcset
	 */
	private function replace_srcset_string( $srcset ) {
		$sources = explode( ',', $srcset );
		$new_sources = array();
		
		foreach ( $sources as $source ) {
			$source = trim( $source );
			$parts = preg_split( '/\s+/', $source, 2 );
			
			if ( ! empty( $parts[0] ) ) {
				$url = wpimages_webp_swap_url( $parts[0] );
				$descriptor = isset( $parts[1] ) ? ' ' . $parts[1] : '';
				$new_sources[] = $url . $descriptor;
			}
		}
		
		return implode( ', ', $new_sources );
	}
	
	/**
	 * Replace attachment image src
	 *
	 * @param array|false $image Image data or false
	 * @return array|false Modified image data
	 */
	public function replace_attachment_url( $image ) {
		if ( ! is_array( $image ) || empty( $image[0] ) ) {
			return $image;
		}
		
		$image[0] = wpimages_webp_swap_url( $image[0] );
		
		return $image;
	}
	
	/**
	 * Replace srcset URLs
	 *
	 * @param array $sources Srcset sources
	 * @return array Modified sources
	 */
	public function replace_srcset_urls( $sources ) {
		if ( ! is_array( $sources ) ) {
			return $sources;
		}
		
		foreach ( $sources as $width => $source ) {
			if ( ! empty( $source['url'] ) ) {
				$sources[ $width ]['url'] = wpimages_webp_swap_url( $source['url'] );
			}
		}
		
		return $sources;
	}
	
	/**
	 * Enqueue frontend scripts
	 */
	public function enqueue_scripts() {
		// Only load on applicable pages
		if ( ! $this->should_load_scripts() ) {
			return;
		}
		
		// Enqueue background swap script
		wp_enqueue_script(
			'wpimages-webp-bg-swap',
			WPIMAGES_WEBP_ASSETS_URL . 'js/frontend-bg-swap.js',
			array(),
			WPIMAGES_WEBP_VERSION,
			true
		);
		
		// Pass uploads URL to JavaScript
		$uploads = wp_get_upload_dir();
		wp_localize_script(
			'wpimages-webp-bg-swap',
			'wpimagesWebpConfig',
			array(
				'uploadsUrl' => esc_url( $uploads['baseurl'] ),
			)
		);
	}
	
	/**
	 * Should load scripts on this page
	 *
	 * @return bool
	 */
	private function should_load_scripts() {
		// Single post or page
		if ( is_singular() ) {
			return true;
		}
		
		// Homepage
		if ( is_front_page() || is_home() ) {
			return true;
		}
		
		// Archives (optional, can be configured)
		if ( is_archive() ) {
			return wpimages_webp_get_option( 'enable_on_archives', false );
		}
		
		return false;
	}
}
