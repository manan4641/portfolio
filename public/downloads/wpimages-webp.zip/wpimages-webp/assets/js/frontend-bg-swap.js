/**
 * Frontend Background Image Swap JavaScript
 */
(function () {
    'use strict';

    // Configuration passed from PHP
    var uploadsUrl = wpimagesWebpConfig.uploadsUrl;

    /**
     * Convert URL to WebP
     */
    function toWebp(url) {
        return url.replace(/\.(jpe?g|png)(\?.*)?$/i, '.webp$2');
    }

    /**
     * Extract background URL from CSS
     */
    function extractBgUrl(bg) {
        if (!bg || bg === 'none') return null;
        var match = bg.match(/url\(["']?([^"')]+)["']?\)/i);
        return match ? match[1] : null;
    }

    /**
     * Try to swap element background to WebP
     */
    function trySwap(el) {
        var bg = getComputedStyle(el).backgroundImage;
        var url = extractBgUrl(bg);

        if (!url) return;

        // Only process uploads directory URLs
        if (url.indexOf(uploadsUrl) !== 0) return;

        // Only process JPG/PNG
        if (!/\.(jpe?g|png)(\?.*)?$/i.test(url)) return;

        var webpUrl = toWebp(url);

        // Test-load WebP
        var img = new Image();
        img.onload = function () {
            el.style.backgroundImage = 'url("' + webpUrl + '")';
        };
        img.onerror = function () {
            // WebP doesn't exist, keep original
        };
        img.src = webpUrl;
    }

    /**
     * Scan all elements
     */
    function scan() {
        var elements = document.querySelectorAll('*');
        for (var i = 0; i < elements.length; i++) {
            trySwap(elements[i]);
        }
    }

    // Initial scan
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', scan);
    } else {
        scan();
    }

    // Observe for dynamic changes (sliders, popups, etc.)
    var observer = new MutationObserver(function (mutations) {
        mutations.forEach(function (mutation) {
            if (mutation.type === 'childList') {
                mutation.addedNodes.forEach(function (node) {
                    if (node.nodeType === 1) { // Element
                        trySwap(node);
                        // Also deep scan new trees
                        var descendants = node.querySelectorAll('*');
                        for (var i = 0; i < descendants.length; i++) {
                            trySwap(descendants[i]);
                        }
                    }
                });
            } else if (mutation.type === 'attributes' && (mutation.attributeName === 'style' || mutation.attributeName === 'class')) {
                trySwap(mutation.target);
            }
        });
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['style', 'class']
    });

})();
