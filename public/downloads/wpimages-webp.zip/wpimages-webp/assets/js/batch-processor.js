/**
 * Batch Processor JavaScript
 */
(function ($) {
    'use strict';

    var scanResults = null;
    var isProcessing = false;

    $(document).ready(function () {

        // Scan button
        $('#wpimages-scan-btn').on('click', function () {
            if (isProcessing) return;

            var $btn = $(this);
            var $results = $('#wpimages-scan-results');
            var $convertSection = $('#wpimages-convert-section');

            $btn.prop('disabled', true).addClass('wpimages-loading');
            $results.html('<p>Scanning posts and images...</p>').removeClass('empty');
            $convertSection.hide();

            $.ajax({
                url: wpimagesWebpAjax.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'wpimages_webp_scan',
                    nonce: wpimagesWebpAjax.nonce
                },
                success: function (response) {
                    if (response.success) {
                        scanResults = response.data;
                        displayScanResults(scanResults);

                        if (scanResults.total_images > 0) {
                            $convertSection.slideDown();
                        }
                    } else {
                        $results.html('<p style="color: red;">Error: ' + response.data.message + '</p>');
                    }
                },
                error: function () {
                    $results.html('<p style="color: red;">An error occurred during scanning.</p>');
                },
                complete: function () {
                    $btn.prop('disabled', false).removeClass('wpimages-loading');
                }
            });
        });

        // Convert button
        $('#wpimages-convert-btn').on('click', function () {
            if (isProcessing || !scanResults || scanResults.total_images === 0) return;

            if (!confirm('This will create WebP versions of ' + scanResults.total_images + ' images. Continue?')) {
                return;
            }

            startConversion();
        });

    });

    /**
     * Display scan results
     */
    function displayScanResults(data) {
        var html = '<div class="wpimages-scan-summary">';
        html += '<p>Found <strong>' + data.total_images + '</strong> images in <strong>' + data.total_posts + '</strong> posts.</p>';
        html += '</div>';

        if (data.post_details && data.post_details.length > 0) {
            html += '<details>';
            html += '<summary style="cursor: pointer; font-weight: bold; margin-bottom: 10px;">View Post Details</summary>';
            html += '<div class="wpimages-post-list">';

            $.each(data.post_details, function (i, post) {
                html += '<div class="wpimages-post-item">';
                html += '<strong>' + escapeHtml(post.title) + '</strong> ';
                html += '<span style="color: #666;">(' + post.type + ')</span> - ';
                html += '<span style="color: #2271b1;">' + post.image_count + ' images</span>';
                html += '</div>';
            });

            html += '</div>';
            html += '</details>';
        }

        $('#wpimages-scan-results').html(html);
    }

    /**
     * Start conversion process
     */
    function startConversion() {
        isProcessing = true;

        var $btn = $('#wpimages-convert-btn');
        var $progressContainer = $('#wpimages-progress-container');
        var $results = $('#wpimages-conversion-results');

        $btn.prop('disabled', true).addClass('wpimages-loading');
        $progressContainer.show();
        $results.empty();

        // Start batch
        $.ajax({
            url: wpimagesWebpAjax.ajaxUrl,
            type: 'POST',
            data: {
                action: 'wpimages_webp_start_batch',
                nonce: wpimagesWebpAjax.nonce,
                image_ids: scanResults.image_ids
            },
            success: function (response) {
                if (response.success) {
                    processBatch();
                } else {
                    showError('Failed to start conversion: ' + response.data.message);
                }
            },
            error: function () {
                showError('An error occurred while starting conversion.');
            }
        });
    }

    /**
     * Process batch (recursive)
     */
    function processBatch() {
        $.ajax({
            url: wpimagesWebpAjax.ajaxUrl,
            type: 'POST',
            data: {
                action: 'wpimages_webp_process_batch',
                nonce: wpimagesWebpAjax.nonce
            },
            success: function (response) {
                if (response.success) {
                    updateProgress(response.data);

                    if (response.data.status === 'completed') {
                        showResults(response.data);
                    } else {
                        // Continue processing
                        setTimeout(processBatch, 500);
                    }
                } else {
                    showError('Error during conversion: ' + response.data.message);
                }
            },
            error: function () {
                showError('An error occurred during conversion.');
            }
        });
    }

    /**
     * Update progress bar
     */
    function updateProgress(data) {
        var percent = data.percent || 0;

        $('.wpimages-progress-fill').css('width', percent + '%');
        $('.wpimages-progress-text').text(percent.toFixed(1) + '%');

        $('#wpimages-progress-status').html(
            'Converting ' + data.processed + ' of ' + data.total + ' images...'
        );
    }

    /**
     * Show completion results
     */
    function showResults(data) {
        isProcessing = false;

        var html = '<div class="wpimages-results-success">✓ Conversion Completed!</div>';
        html += '<div class="wpimages-results-stats">';
        html += '<p><strong>Total Images:</strong> ' + data.total + '</p>';
        html += '<p><strong>Successfully Converted:</strong> ' + data.success + '</p>';
        html += '<p><strong>Skipped (already exist):</strong> ' + data.skipped + '</p>';

        if (data.failed > 0) {
            html += '<p style="color: #dc3545;"><strong>Failed:</strong> ' + data.failed + '</p>';
        }

        html += '</div>';

        $('#wpimages-conversion-results').html(html);
        $('#wpimages-convert-btn').prop('disabled', false).removeClass('wpimages-loading');

        // Refresh page to show updated last run
        setTimeout(function () {
            location.reload();
        }, 60000);
    }

    /**
     * Show error
     */
    function showError(message) {
        isProcessing = false;

        $('#wpimages-conversion-results').html(
            '<p style="color: red; font-weight: bold;">✗ ' + escapeHtml(message) + '</p>'
        );

        $('#wpimages-convert-btn').prop('disabled', false).removeClass('wpimages-loading');
    }

    /**
     * Escape HTML
     */
    function escapeHtml(text) {
        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, function (m) { return map[m]; });
    }

})(jQuery);
