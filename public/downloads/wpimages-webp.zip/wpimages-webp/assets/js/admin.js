/**
 * Admin JavaScript
 */
(function ($) {
	'use strict';

	$(document).ready(function () {

		// Quality slider
		var $qualitySlider = $('.wpimages-quality-slider');
		var $qualityValue = $('.wpimages-quality-value');

		$qualitySlider.on('input', function () {
			$qualityValue.text($(this).val());
		});

		// View logs
		$('#wpimages-view-logs-btn').on('click', function () {
			$('#wpimages-logs-content').slideToggle();
		});

		// Clear logs
		$('#wpimages-clear-logs-btn').on('click', function () {
			if (!confirm('Are you sure you want to clear all logs?')) {
				return;
			}

			var $btn = $(this);
			$btn.prop('disabled', true).text('Clearing...');

			$.ajax({
				url: wpimagesWebpAjax.ajaxUrl,
				type: 'POST',
				data: {
					action: 'wpimages_webp_clear_logs',
					nonce: wpimagesWebpAjax.nonce
				},
				success: function (response) {
					if (response.success) {
						$('#wpimages-logs-content pre').text('No logs available.');
						alert('Logs cleared successfully!');
					} else {
						alert('Error: ' + response.data.message);
					}
				},
				error: function () {
					alert('An error occurred while clearing logs.');
				},
				complete: function () {
					$btn.prop('disabled', false).text('Clear Logs');
				}
			});
		});

		// Tab Switching
		$('.wpimages-tab').on('click', function () {
			var tabId = $(this).data('tab');

			// Update active tab
			$('.wpimages-tab').removeClass('active');
			$(this).addClass('active');

			// Show corresponding panel
			$('.wpimages-tab-panel').removeClass('active');
			$('#' + tabId).addClass('active');

			// Store active tab in localStorage
			localStorage.setItem('wpimages_active_tab', tabId);
		});

		// Restore last active tab
		var activeTab = localStorage.getItem('wpimages_active_tab');
		if (activeTab && $('#' + activeTab).length) {
			$('.wpimages-tab[data-tab="' + activeTab + '"]').trigger('click');
		}

		// Image Size Selection Toggle
		$('input[name="conversion_scope"]').on('change', function () {
			if ($(this).val() === 'custom') {
				$('#wpimages-custom-sizes').slideDown();
			} else {
				$('#wpimages-custom-sizes').slideUp();
			}
		});

		// Initial state
		if ($('input[name="conversion_scope"]:checked').val() === 'custom') {
			$('#wpimages-custom-sizes').show();
		} else {
			$('#wpimages-custom-sizes').hide();
		}
	});

})(jQuery);
